import cv2

image = cv2.imread('1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG')
print(f"Type of the image: {type(image)}")
print(f"Shape of the image array: {image.shape}")
