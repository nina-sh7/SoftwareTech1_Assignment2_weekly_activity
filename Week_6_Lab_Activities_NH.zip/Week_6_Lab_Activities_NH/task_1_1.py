# -*- coding: utf-8 -*-

#loading the image

import matplotlib.pyplot as plt
# example of loading an image with the Keras API
from keras.preprocessing.image import load_img

# load the image
img_path = '/content/drive/MyDrive/Week_6_Lab_Activities_NH/1_Gammar_2021_1_2021_06_03-13-19-23-856.PNG'
img = load_img(img_path)

# report details about the image
print(type(img))
print(img.format)
print(img.mode)
print(img.size)

# show the image using matplotlib
plt.imshow(img)
plt.axis('off') # turn off axis labels
plt.show()
